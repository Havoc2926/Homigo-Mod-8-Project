from flask import Flask, request, jsonify, render_template
import requests
import json
import os


GOVEE_API_KEY = "f66377a4-4aeb-487e-8685-bf07293f48bc"
SCENE_FILE = 'scenes.json'


app = Flask(__name__)

#PYTHON FUNCTIONS!!

def get_govee_lights():
    headers = {
        "Govee-API-Key": GOVEE_API_KEY
    }
    response = requests.get("https://developer-api.govee.com/v1/devices", headers=headers)
    if response.status_code == 200:
        devices = response.json().get("data", {}).get("devices", [])
        return [
            {"device": d["device"], "name": d["deviceName"], "model": d["model"]}
            for d in devices
        ]
    return []

def load_scenes():
    if not os.path.exists(SCENE_FILE):
        return {"happy": {}, "focus": {}, "party": {}}
    with open(SCENE_FILE, 'r') as f:
        return json.load(f)

def save_scenes(scenes):
    with open(SCENE_FILE, 'w') as f:
        json.dump(scenes, f, indent=4)

def hex_to_rgb(hex_color):
    """Convert hex (#RRGGBB) to RGB dict"""
    hex_color = hex_color.lstrip("#")
    return {
        "r": int(hex_color[0:2], 16),
        "g": int(hex_color[2:4], 16),
        "b": int(hex_color[4:6], 16)
    }

def set_scene(scene_name):
    # Load scenes
    with open(SCENE_FILE, "r") as f:
        scenes = json.load(f)
    scene = scenes.get(scene_name, {})
    if not scene:
        return {"error": "Scene not found or empty"}, 404

    # Load device list (for model info)
    lights = get_govee_lights()  # uses Govee API
    model_lookup = {d["device"]: d["model"] for d in lights}

    results = []
    for device_id, hex_color in scene.items():
        rgb = hex_to_rgb(hex_color)
        model = model_lookup.get(device_id, "")

        payload = {
            "device": device_id,
            "model": model,
            "cmd": {
                "name": "color",
                "value": rgb
            }
        }
        headers = {
            "Govee-API-Key": GOVEE_API_KEY,
            "Content-Type": "application/json"
        }

        response = requests.put(
            "https://developer-api.govee.com/v1/devices/control",
            headers=headers,
            json=payload
        )

        results.append({
            "device": device_id,
            "status": response.status_code,
            "response": response.text
        })

    return {"message": f"Scene '{scene_name}' triggered", "results": results}, 200

#APP ROUTES BELOW!!

@app.route('/')
def hello():
    return 'Hello, World!'

@app.route('/lights')
def getLights():
    return jsonify(get_govee_lights())

@app.route('/api/scenes', methods=['GET'])
def getScenes():
    return jsonify(load_scenes())

@app.route('/api/scenes', methods=['POST'])
def update_scene():
    data = request.json
    scene_name = data.get("name")
    colors = data.get("colors")

    if scene_name not in ["happy", "focus", "party"]:
        return jsonify({"error": "Invalid scene name"}), 400

    if not isinstance(colors, dict):
        return jsonify({"error": "Invalid colors format"}), 400

    scenes = load_scenes()
    scenes[scene_name] = colors
    save_scenes(scenes)

    return jsonify({"message": f"Scene '{scene_name}' updated successfully"})


@app.route('/api/trigger/<scene_name>', methods=['GET'])
def triggerScene(scene_name):
    if scene_name not in ["happy", "focus", "party"]:
        return jsonify({"error": "Invalid scene name"}), 400

    result, status = set_scene(scene_name)
    return jsonify(result), status
